"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, Wand2, Zap, FileText, Plus, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import PDFEditor from "@/components/pdf-editor"

export default function Home() {
  const [pdfFile, setPdfFile] = useState<File | null>(null)
  const [showEditor, setShowEditor] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = (file: File) => {
    if (file.type === "application/pdf") {
      setPdfFile(file)
      setShowEditor(true)
    } else {
      alert("Please upload a valid PDF file")
    }
  }

  const handleDragDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file) handleFileUpload(file)
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.currentTarget.files?.[0]
    if (file) handleFileUpload(file)
  }

  if (showEditor && pdfFile) {
    return (
      <PDFEditor
        file={pdfFile}
        onBack={() => {
          setPdfFile(null)
          setShowEditor(false)
        }}
      />
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      <div className="container mx-auto px-4 py-8 sm:py-12 md:py-16">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <div className="flex items-center justify-center mb-4 gap-3">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Wand2 className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              PDF Genie
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your all-in-one PDF editor with AI assistance. Compress, edit, annotate, and transform PDFs effortlessly.
          </p>
        </div>

        {/* Upload Section */}
        <div className="max-w-2xl mx-auto mb-12">
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDragDrop}
            className="border-2 border-dashed border-primary/30 hover:border-primary/60 rounded-xl p-8 md:p-12 bg-card/50 backdrop-blur-sm transition-all cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="text-center">
              <div className="mb-4 flex justify-center">
                <Upload className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-xl md:text-2xl font-semibold mb-2">Upload or Drag & Drop PDF</h2>
              <p className="text-muted-foreground mb-4">Click to browse or drag your PDF file here</p>
              <Button className="bg-primary hover:bg-primary/90">Select PDF</Button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf"
              onChange={handleFileInputChange}
              className="hidden"
              aria-label="Upload PDF file"
            />
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <FeatureCard
            icon={Zap}
            title="Lightning Compression"
            description="Reduce PDF file size to 100KB or less while maintaining quality"
          />
          <FeatureCard
            icon={FileText}
            title="Full Editing Suite"
            description="Edit text, add images, adjust formatting and styling"
          />
          <FeatureCard
            icon={Plus}
            title="Annotations & Drawing"
            description="Highlight, comment, draw, and mark up your PDFs"
          />
          <FeatureCard icon={Wand2} title="AI Assistant" description="Get intelligent suggestions and PDF analysis" />
          <FeatureCard
            icon={Settings}
            title="Header & Footer"
            description="Add custom headers, footers, and page numbers"
          />
          <FeatureCard
            icon={Zap}
            title="Offline Access"
            description="All processing happens locally, no server uploads"
          />
        </div>
      </div>
    </main>
  )
}

function FeatureCard({ icon: Icon, title, description }: { icon: any; title: string; description: string }) {
  return (
    <Card className="p-6 bg-card/50 backdrop-blur-sm border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
      <div className="p-3 bg-accent/10 rounded-lg w-fit mb-4">
        <Icon className="w-6 h-6 text-accent" />
      </div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </Card>
  )
}
