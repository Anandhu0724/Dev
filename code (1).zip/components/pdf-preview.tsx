"use client"

import { useEffect, useRef, useState } from "react"
import * as pdfjs from "pdfjs-dist"
import { ZoomIn, ZoomOut } from "lucide-react"
import { Button } from "@/components/ui/button"

pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@5.4.296/build/pdf.worker.min.mjs`

interface PDFPreviewProps {
  file: File
  currentPage: number
  onPageChange: (page: number) => void
  onTotalPagesChange: (total: number) => void
  editMode: string | null
  textBoxes?: Array<{
    id: string
    x: number
    y: number
    text: string
    fontSize: number
    fontFamily: string
    bold: boolean
    italic: boolean
    underline: boolean
    textColor: string
    alignment: "left" | "center" | "right"
  }>
  annotations?: Array<{
    id: string
    type: string
    x: number
    y: number
    text?: string
    color: string
    width?: number
    points?: Array<{ x: number; y: number }>
  }>
}

export default function PDFPreview({
  file,
  currentPage,
  onPageChange,
  onTotalPagesChange,
  editMode,
  textBoxes = [],
  annotations = [],
}: PDFPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [loading, setLoading] = useState(true)
  const [zoom, setZoom] = useState(100)
  const [pdfDocument, setPdfDocument] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadPDF = async () => {
      setLoading(true)
      setError(null)
      try {
        const arrayBuffer = await file.arrayBuffer()
        console.log("[v0] Loading PDF document...")
        const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise
        console.log("[v0] PDF loaded successfully, pages:", pdf.numPages)
        setPdfDocument(pdf)
        onTotalPagesChange(pdf.numPages)
        renderPage(pdf, currentPage, zoom)
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : "Unknown error loading PDF"
        console.error("[v0] Error loading PDF:", errorMsg)
        setError(`Error loading PDF: ${errorMsg}`)
        setLoading(false)
      }
    }

    loadPDF()
  }, [file, onTotalPagesChange])

  const renderPage = async (pdf: any, pageNum: number, zoomLevel: number) => {
    try {
      const page = await pdf.getPage(pageNum)
      const baseScale = window.innerWidth < 768 ? 1 : 1.5
      const scale = (baseScale * zoomLevel) / 100
      const viewport = page.getViewport({ scale })

      const canvas = canvasRef.current
      if (!canvas) return

      const context = canvas.getContext("2d")
      if (!context) return

      canvas.width = viewport.width
      canvas.height = viewport.height

      const renderTask = page.render({
        canvasContext: context,
        viewport,
      })

      await renderTask.promise
      renderOverlay(viewport)
      setLoading(false)
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : "Unknown error rendering page"
      console.error("[v0] Error rendering page:", errorMsg)
      setError(`Error rendering page: ${errorMsg}`)
      setLoading(false)
    }
  }

  const renderOverlay = (viewport: any) => {
    const overlayCanvas = overlayCanvasRef.current
    if (!overlayCanvas) return

    const ctx = overlayCanvas.getContext("2d")
    if (!ctx) return

    overlayCanvas.width = viewport.width
    overlayCanvas.height = viewport.height
    ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height)

    textBoxes.forEach((textBox) => {
      const fontStyle = `${textBox.italic ? "italic" : ""} ${textBox.bold ? "bold" : ""} ${textBox.fontSize}px ${textBox.fontFamily}`
      ctx.font = fontStyle.trim()
      ctx.fillStyle = textBox.textColor || "#000000"

      // Set text alignment
      if (textBox.alignment === "center") {
        ctx.textAlign = "center"
      } else if (textBox.alignment === "right") {
        ctx.textAlign = "right"
      } else {
        ctx.textAlign = "left"
      }

      // Draw text with underline if needed
      ctx.fillText(textBox.text, textBox.x, textBox.y)

      if (textBox.underline) {
        const metrics = ctx.measureText(textBox.text)
        const underlineY = textBox.y + 3
        ctx.strokeStyle = textBox.textColor || "#000000"
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(textBox.x, underlineY)
        ctx.lineTo(textBox.x + metrics.width, underlineY)
        ctx.stroke()
      }
    })

    annotations.forEach((annotation) => {
      if (annotation.type === "highlight") {
        ctx.fillStyle = "rgba(255, 255, 0, 0.3)"
        ctx.fillRect(annotation.x, annotation.y, 100, 20)
      } else if (annotation.type === "comment") {
        ctx.fillStyle = "rgba(255, 200, 0, 0.2)"
        ctx.fillRect(annotation.x, annotation.y, 80, 40)
        ctx.fillStyle = "#333"
        ctx.font = "12px Arial"
        ctx.textAlign = "left"
        ctx.fillText(annotation.text || "", annotation.x + 5, annotation.y + 15)
      } else if (annotation.type === "draw" && annotation.points && annotation.points.length > 0) {
        ctx.strokeStyle = annotation.color || "#000000"
        ctx.lineWidth = annotation.width || 2
        ctx.lineCap = "round"
        ctx.lineJoin = "round"
        ctx.beginPath()
        ctx.moveTo(annotation.points[0].x, annotation.points[0].y)
        for (let i = 1; i < annotation.points.length; i++) {
          ctx.lineTo(annotation.points[i].x, annotation.points[i].y)
        }
        ctx.stroke()
      }
    })
  }

  useEffect(() => {
    if (pdfDocument) {
      renderPage(pdfDocument, currentPage, zoom)
    }
  }, [currentPage, zoom, pdfDocument, textBoxes, annotations])

  const handleZoom = (direction: "in" | "out") => {
    setZoom((prev) => {
      const newZoom = direction === "in" ? prev + 25 : prev - 25
      return Math.max(50, Math.min(200, newZoom))
    })
  }

  return (
    <div className="flex flex-col items-center justify-center flex-1 bg-muted/30 rounded-lg overflow-hidden">
      {/* Zoom Controls */}
      <div className="flex gap-2 p-3 border-b w-full justify-center bg-card/50 backdrop-blur-sm">
        <Button variant="outline" size="sm" onClick={() => handleZoom("out")} disabled={zoom <= 50} className="gap-1">
          <ZoomOut className="w-4 h-4" />
          {zoom}%
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleZoom("in")} disabled={zoom >= 200} className="gap-1">
          <ZoomIn className="w-4 h-4" />
        </Button>
      </div>

      {/* PDF Canvas Container */}
      <div
        ref={containerRef}
        className={`flex flex-col items-center justify-start flex-1 w-full overflow-auto p-4 ${
          editMode ? "cursor-crosshair" : "cursor-default"
        }`}
      >
        <div className="relative bg-white rounded-lg shadow-lg">
          <canvas ref={canvasRef} className="max-w-full h-auto block" />
          <canvas
            ref={overlayCanvasRef}
            className="absolute top-0 left-0 max-w-full h-auto cursor-default"
            style={{ cursor: editMode ? "crosshair" : "default" }}
          />
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm rounded-lg">
          <div className="bg-card p-4 rounded-lg">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm rounded-lg">
          <div className="bg-destructive/90 text-destructive-foreground p-4 rounded-lg max-w-sm">
            <p className="text-sm font-medium">{error}</p>
          </div>
        </div>
      )}
    </div>
  )
}
