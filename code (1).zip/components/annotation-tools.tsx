"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Highlighter, PenTool, MessageCircle, Trash2, Undo2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface Annotation {
  id: string
  type: "highlight" | "comment" | "draw"
  x: number
  y: number
  text?: string
  color: string
  width?: number
  points?: Array<{ x: number; y: number }>
}

interface AnnotationToolsProps {
  annotations: Annotation[]
  onAddAnnotation: (annotation: Omit<Annotation, "id">) => void
  onDeleteAnnotation: (id: string) => void
  onClearAnnotations: () => void
}

export default function AnnotationTools({
  annotations,
  onAddAnnotation,
  onDeleteAnnotation,
  onClearAnnotations,
}: AnnotationToolsProps) {
  const [tool, setTool] = useState<"highlight" | "comment" | "draw" | null>(null)
  const [highlightColor, setHighlightColor] = useState("#FFFF00")
  const [penColor, setPenColor] = useState("#FF0000")
  const [penWidth, setPenWidth] = useState(2)
  const [commentText, setCommentText] = useState("")
  const [showCommentDialog, setShowCommentDialog] = useState(false)
  const [isDrawing, setIsDrawing] = useState(false)
  const drawingCanvasRef = useRef<HTMLCanvasElement>(null)
  const [currentPath, setCurrentPath] = useState<Array<{ x: number; y: number }>>([])

  useEffect(() => {
    if (tool === "draw" && drawingCanvasRef.current) {
      const canvas = drawingCanvasRef.current
      canvas.width = canvas.clientWidth
      canvas.height = canvas.clientHeight
    }
  }, [tool])

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (tool !== "draw") return

    setIsDrawing(true)
    const canvas = drawingCanvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setCurrentPath([{ x, y }])
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || tool !== "draw") return

    const canvas = drawingCanvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setCurrentPath((prev) => [...prev, { x, y }])

    // Draw line
    if (currentPath.length > 0) {
      const lastPoint = currentPath[currentPath.length - 1]
      ctx.strokeStyle = penColor
      ctx.lineWidth = penWidth
      ctx.lineCap = "round"
      ctx.lineJoin = "round"
      ctx.beginPath()
      ctx.moveTo(lastPoint.x, lastPoint.y)
      ctx.lineTo(x, y)
      ctx.stroke()
    }
  }

  const handleMouseUp = () => {
    if (!isDrawing || tool !== "draw" || currentPath.length === 0) {
      setIsDrawing(false)
      return
    }

    setIsDrawing(false)

    const newAnnotation: Annotation = {
      id: Date.now().toString(),
      type: "draw",
      x: currentPath[0].x,
      y: currentPath[0].y,
      color: penColor,
      width: penWidth,
      points: currentPath,
    }

    onAddAnnotation(newAnnotation)
    setCurrentPath([])
  }

  const handleAddHighlight = () => {
    onAddAnnotation({
      type: "highlight",
      x: 0,
      y: 0,
      color: highlightColor,
    })
    setTool(null)
  }

  const handleAddComment = () => {
    if (!commentText.trim()) return

    onAddAnnotation({
      type: "comment",
      x: 0,
      y: 0,
      text: commentText,
      color: "#FDB022",
    })

    setCommentText("")
    setShowCommentDialog(false)
  }

  return (
    <div className="space-y-3">
      {/* Tool Selection */}
      <div className="grid grid-cols-1 gap-2">
        <Button
          onClick={() => setTool(tool === "highlight" ? null : "highlight")}
          variant={tool === "highlight" ? "default" : "outline"}
          className="justify-start h-auto py-3"
        >
          <Highlighter className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Highlight</div>
            <div className="text-xs opacity-70">Mark important text</div>
          </div>
        </Button>

        <Button onClick={() => setShowCommentDialog(true)} variant="outline" className="justify-start h-auto py-3">
          <MessageCircle className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Add Comment</div>
            <div className="text-xs opacity-70">Add notes and comments</div>
          </div>
        </Button>

        <Button
          onClick={() => setTool(tool === "draw" ? null : "draw")}
          variant={tool === "draw" ? "default" : "outline"}
          className="justify-start h-auto py-3"
        >
          <PenTool className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Draw</div>
            <div className="text-xs opacity-70">Draw freehand marks</div>
          </div>
        </Button>
      </div>

      {/* Drawing Canvas */}
      {tool === "draw" && (
        <div className="relative border rounded-lg overflow-hidden bg-transparent">
          <canvas
            ref={drawingCanvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="w-full cursor-crosshair"
          />
        </div>
      )}

      {/* Highlight Settings */}
      {tool === "highlight" && (
        <Card className="p-4 space-y-4">
          <div>
            <Label htmlFor="highlight-color">Highlight Color</Label>
            <div className="flex gap-2 mt-2">
              <input
                id="highlight-color"
                type="color"
                value={highlightColor}
                onChange={(e) => setHighlightColor(e.target.value)}
                className="w-12 h-10 rounded border border-input cursor-pointer"
              />
              <Button onClick={handleAddHighlight} className="flex-1 bg-primary hover:bg-primary/90">
                Add Highlight
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Drawing Settings */}
      {tool === "draw" && (
        <Card className="p-4 space-y-4">
          <div>
            <Label htmlFor="pen-color">Pen Color</Label>
            <div className="flex gap-2 mt-2">
              <input
                id="pen-color"
                type="color"
                value={penColor}
                onChange={(e) => setPenColor(e.target.value)}
                className="w-12 h-10 rounded border border-input cursor-pointer"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="pen-width">Pen Width: {penWidth}px</Label>
            <input
              id="pen-width"
              type="range"
              min="1"
              max="10"
              value={penWidth}
              onChange={(e) => setPenWidth(Number(e.target.value))}
              className="w-full mt-2"
            />
          </div>
        </Card>
      )}

      {/* Comment Dialog */}
      <Dialog open={showCommentDialog} onOpenChange={setShowCommentDialog}>
        <DialogTrigger asChild>
          <div style={{ display: "none" }} />
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Comment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Enter your comment..."
              className="w-full px-3 py-2 border rounded-md bg-background min-h-24"
            />
            <Button onClick={handleAddComment} className="w-full bg-primary hover:bg-primary/90">
              Add Comment
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Annotations List */}
      {annotations.length > 0 && (
        <Card className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm">Annotations ({annotations.length})</h3>
            <Button variant="outline" size="sm" onClick={onClearAnnotations} className="gap-1 bg-transparent">
              <Undo2 className="w-3 h-3" />
              Clear All
            </Button>
          </div>
          <div className="space-y-2 max-h-40 overflow-auto">
            {annotations.map((ann) => (
              <div
                key={ann.id}
                className="p-2 rounded border border-input hover:border-primary/50 transition-all flex items-start justify-between gap-2"
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium capitalize">{ann.type}</div>
                  {ann.type === "comment" && <div className="text-xs text-muted-foreground truncate">{ann.text}</div>}
                  {ann.type === "draw" && (
                    <div className="text-xs text-muted-foreground">Points: {ann.points?.length || 0}</div>
                  )}
                </div>
                <Button variant="ghost" size="sm" onClick={() => onDeleteAnnotation(ann.id)} className="shrink-0">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
