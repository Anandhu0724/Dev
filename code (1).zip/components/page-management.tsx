"use client"

import { useState } from "react"
import { Trash2, Copy, Settings, ChevronUp, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface HeaderFooterConfig {
  header: {
    enabled: boolean
    text: string
    position: "left" | "center" | "right"
  }
  footer: {
    enabled: boolean
    text: string
    position: "left" | "center" | "right"
    showPageNumbers: boolean
  }
}

interface PageManagementProps {
  totalPages: number
  currentPage: number
  onPageChange: (page: number) => void
}

export default function PageManagement({ totalPages, currentPage, onPageChange }: PageManagementProps) {
  const [headerFooter, setHeaderFooter] = useState<HeaderFooterConfig>({
    header: { enabled: false, text: "", position: "center" },
    footer: { enabled: false, text: "", position: "center", showPageNumbers: true },
  })
  const [showHeaderFooterDialog, setShowHeaderFooterDialog] = useState(false)
  const [selectedPages, setSelectedPages] = useState<number[]>([])

  const handleUpdateHeaderFooter = () => {
    // Store configuration for PDF export
    localStorage.setItem("headerFooterConfig", JSON.stringify(headerFooter))
    setShowHeaderFooterDialog(false)
  }

  const handleDeletePage = (page: number) => {
    if (totalPages <= 1) {
      alert("Cannot delete the last page")
      return
    }
    // Page deletion logic would be implemented here
    alert(`Would delete page ${page}`)
  }

  const handleDuplicatePage = (page: number) => {
    // Page duplication logic would be implemented here
    alert(`Would duplicate page ${page}`)
  }

  const handleMovePage = (page: number, direction: "up" | "down") => {
    if ((direction === "up" && page === 1) || (direction === "down" && page === totalPages)) {
      return
    }
    // Page reordering logic would be implemented here
  }

  const handleTogglePageSelection = (page: number) => {
    setSelectedPages((prev) => (prev.includes(page) ? prev.filter((p) => p !== page) : [...prev, page]))
  }

  return (
    <div className="space-y-4">
      {/* Page Navigation Controls */}
      <Card className="p-4 space-y-3">
        <h3 className="font-semibold text-sm">Pages ({totalPages})</h3>

        {/* Page Thumbnails / List */}
        <div className="space-y-2 max-h-48 overflow-auto">
          {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => i + 1).map((page) => (
            <div
              key={page}
              className={`flex items-center justify-between p-2 rounded border cursor-pointer transition-all ${
                page === currentPage ? "border-primary bg-primary/10" : "border-input hover:border-primary/50"
              }`}
              onClick={() => onPageChange(page)}
            >
              <div className="flex items-center gap-2 flex-1">
                <input
                  type="checkbox"
                  checked={selectedPages.includes(page)}
                  onChange={(e) => {
                    e.stopPropagation()
                    handleTogglePageSelection(page)
                  }}
                  className="w-4 h-4 cursor-pointer"
                />
                <span className="text-sm font-medium">Page {page}</span>
              </div>
              <div className="flex gap-1 opacity-0 hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleMovePage(page, "up")
                  }}
                  disabled={page === 1}
                  className="p-1"
                >
                  <ChevronUp className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleMovePage(page, "down")
                  }}
                  disabled={page === totalPages}
                  className="p-1"
                >
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
          {totalPages > 10 && (
            <div className="text-xs text-muted-foreground text-center py-2">+{totalPages - 10} more pages</div>
          )}
        </div>

        {/* Batch Operations */}
        {selectedPages.length > 0 && (
          <div className="flex gap-2 pt-2 border-t">
            <Button
              variant="outline"
              size="sm"
              className="flex-1 gap-1 bg-transparent"
              onClick={() => handleDuplicatePage(selectedPages[0])}
            >
              <Copy className="w-3 h-3" />
              Duplicate
            </Button>
            <Button
              variant="destructive"
              size="sm"
              className="flex-1 gap-1"
              onClick={() => handleDeletePage(selectedPages[0])}
            >
              <Trash2 className="w-3 h-3" />
              Delete
            </Button>
          </div>
        )}
      </Card>

      {/* Header & Footer Settings */}
      <Dialog open={showHeaderFooterDialog} onOpenChange={setShowHeaderFooterDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full gap-2 bg-transparent">
            <Settings className="w-4 h-4" />
            Header & Footer
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Header & Footer Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {/* Header Settings */}
            <div className="space-y-3 p-4 border rounded-lg">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="header-enabled"
                  checked={headerFooter.header.enabled}
                  onChange={(e) =>
                    setHeaderFooter((prev) => ({
                      ...prev,
                      header: { ...prev.header, enabled: e.target.checked },
                    }))
                  }
                  className="w-4 h-4"
                />
                <Label htmlFor="header-enabled" className="font-semibold cursor-pointer">
                  Add Header
                </Label>
              </div>

              {headerFooter.header.enabled && (
                <div className="space-y-3 ml-6">
                  <div>
                    <Label htmlFor="header-text" className="text-xs">
                      Header Text
                    </Label>
                    <Input
                      id="header-text"
                      value={headerFooter.header.text}
                      onChange={(e) =>
                        setHeaderFooter((prev) => ({
                          ...prev,
                          header: { ...prev.header, text: e.target.value },
                        }))
                      }
                      placeholder="Enter header text..."
                      className="text-sm mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="header-position" className="text-xs">
                      Position
                    </Label>
                    <select
                      id="header-position"
                      value={headerFooter.header.position}
                      onChange={(e) =>
                        setHeaderFooter((prev) => ({
                          ...prev,
                          header: { ...prev.header, position: e.target.value as "left" | "center" | "right" },
                        }))
                      }
                      className="w-full px-2 py-1 border rounded text-sm mt-1 bg-background"
                    >
                      <option value="left">Left</option>
                      <option value="center">Center</option>
                      <option value="right">Right</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Settings */}
            <div className="space-y-3 p-4 border rounded-lg">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="footer-enabled"
                  checked={headerFooter.footer.enabled}
                  onChange={(e) =>
                    setHeaderFooter((prev) => ({
                      ...prev,
                      footer: { ...prev.footer, enabled: e.target.checked },
                    }))
                  }
                  className="w-4 h-4"
                />
                <Label htmlFor="footer-enabled" className="font-semibold cursor-pointer">
                  Add Footer
                </Label>
              </div>

              {headerFooter.footer.enabled && (
                <div className="space-y-3 ml-6">
                  <div>
                    <Label htmlFor="footer-text" className="text-xs">
                      Footer Text
                    </Label>
                    <Input
                      id="footer-text"
                      value={headerFooter.footer.text}
                      onChange={(e) =>
                        setHeaderFooter((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, text: e.target.value },
                        }))
                      }
                      placeholder="Enter footer text..."
                      className="text-sm mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="footer-position" className="text-xs">
                      Position
                    </Label>
                    <select
                      id="footer-position"
                      value={headerFooter.footer.position}
                      onChange={(e) =>
                        setHeaderFooter((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, position: e.target.value as "left" | "center" | "right" },
                        }))
                      }
                      className="w-full px-2 py-1 border rounded text-sm mt-1 bg-background"
                    >
                      <option value="left">Left</option>
                      <option value="center">Center</option>
                      <option value="right">Right</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="page-numbers"
                      checked={headerFooter.footer.showPageNumbers}
                      onChange={(e) =>
                        setHeaderFooter((prev) => ({
                          ...prev,
                          footer: { ...prev.footer, showPageNumbers: e.target.checked },
                        }))
                      }
                      className="w-4 h-4"
                    />
                    <Label htmlFor="page-numbers" className="text-xs cursor-pointer">
                      Show Page Numbers
                    </Label>
                  </div>
                </div>
              )}
            </div>

            <Button onClick={handleUpdateHeaderFooter} className="w-full bg-primary hover:bg-primary/90">
              Apply Settings
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Page Statistics */}
      <Card className="p-3 bg-muted/50 space-y-2">
        <p className="text-xs font-medium">Page Information</p>
        <div className="text-xs text-muted-foreground space-y-1">
          <p>Total Pages: {totalPages}</p>
          <p>Current: {currentPage}</p>
          {selectedPages.length > 0 && <p>Selected: {selectedPages.length}</p>}
        </div>
      </Card>
    </div>
  )
}
