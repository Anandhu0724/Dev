"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Loader2, Lightbulb, Copy, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Message {
  id: string
  type: "user" | "ai"
  content: string
  timestamp: Date
}

interface AIAssistantProps {
  fileName: string
}

const QUICK_SUGGESTIONS = [
  "Summarize this document",
  "Find important sections",
  "Extract key information",
  "Identify action items",
]

const AI_SUGGESTIONS = [
  {
    title: "Optimize Document",
    description: "Get suggestions to improve your PDF layout and readability",
    prompt: "How can I improve the layout and readability of this PDF?",
  },
  {
    title: "Extract Data",
    description: "Extract tables and structured data from the document",
    prompt: "Please extract any tables or structured data from this PDF",
  },
  {
    title: "Find Issues",
    description: "Identify potential issues or inconsistencies",
    prompt: "Are there any issues or inconsistencies in this PDF?",
  },
  {
    title: "Summarize",
    description: "Get a comprehensive summary of the content",
    prompt: "Please provide a summary of this PDF document",
  },
]

export default function AIAssistant({ fileName }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "ai",
      content: `Hi! I'm your PDF Genie assistant. I can help you optimize, analyze, or improve "${fileName}". What would you like to do?`,
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [activeTab, setActiveTab] = useState("chat")

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setLoading(true)

    setTimeout(() => {
      const suggestions = [
        "I can help with that! Here are some suggestions:\n\n• Optimize image compression for faster loading\n• Remove unnecessary metadata to reduce file size\n• Reorganize sections for better flow\n• Add bookmarks for easier navigation",
        "Great question! Consider these improvements:\n\n• Ensure consistent formatting throughout\n• Use clear headings and subheadings\n• Add page numbers for reference\n• Include a table of contents",
        "Here's what I found:\n\n• The document has good structure\n• Some images could be compressed further\n• Consider adding alt text to images\n• Font sizes are readable and consistent",
        "Based on the analysis:\n\n• Document quality is good\n• File size could be reduced by 20-30%\n• All text is readable\n• Consider adding index or bookmarks",
      ]

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: suggestions[Math.floor(Math.random() * suggestions.length)],
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setLoading(false)
    }, 1500)
  }

  const handleQuickSuggestion = (suggestion: string) => {
    setInput(suggestion)
  }

  const handleAISuggestion = (prompt: string) => {
    setInput(prompt)
  }

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleClearChat = () => {
    setMessages([
      {
        id: "1",
        type: "ai",
        content: `Hi! I'm your PDF Genie assistant. I can help you optimize, analyze, or improve "${fileName}". What would you like to do?`,
        timestamp: new Date(),
      },
    ])
  }

  return (
    <Card className="flex flex-col h-96 bg-card/50 backdrop-blur-sm border-primary/10 overflow-hidden">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
        </TabsList>

        {/* Chat Tab */}
        <TabsContent value="chat" className="flex flex-col flex-1 min-h-0 p-0">
          <div className="flex-1 overflow-auto p-4 space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    msg.type === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                  } whitespace-pre-wrap text-sm group relative`}
                >
                  {msg.content}
                  {msg.type === "ai" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCopyMessage(msg.content)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity absolute -right-8 top-0"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-2 items-center text-sm">
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.4s" }} />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="border-t p-3 space-y-2 bg-card/30">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
              placeholder="Ask me anything..."
              className="w-full px-3 py-2 border rounded-md bg-background text-sm"
              disabled={loading}
            />
            <Button
              onClick={handleSend}
              disabled={loading || !input.trim()}
              size="sm"
              className="w-full gap-2 bg-primary hover:bg-primary/90"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Thinking...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Send
                </>
              )}
            </Button>
          </div>
        </TabsContent>

        {/* Suggestions Tab */}
        <TabsContent value="suggestions" className="flex flex-col flex-1 min-h-0 overflow-auto p-4 space-y-4">
          <div>
            <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
              <Lightbulb className="w-4 h-4" />
              Quick Suggestions
            </h3>
            <div className="space-y-2">
              {QUICK_SUGGESTIONS.map((suggestion) => (
                <Button
                  key={suggestion}
                  onClick={() => handleQuickSuggestion(suggestion)}
                  variant="outline"
                  className="w-full justify-start h-auto py-2 text-left text-xs"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>

          <div className="border-t pt-3">
            <h3 className="font-semibold text-sm mb-2">AI Analysis</h3>
            <div className="space-y-2">
              {AI_SUGGESTIONS.map((item) => (
                <Button
                  key={item.title}
                  onClick={() => handleAISuggestion(item.prompt)}
                  variant="outline"
                  className="w-full justify-start h-auto py-3 text-left"
                >
                  <div className="space-y-1">
                    <div className="font-medium text-xs">{item.title}</div>
                    <div className="text-xs opacity-70">{item.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          <Button
            onClick={handleClearChat}
            variant="outline"
            size="sm"
            className="w-full gap-2 text-destructive bg-transparent"
          >
            <Trash2 className="w-4 h-4" />
            Clear Chat
          </Button>
        </TabsContent>
      </Tabs>
    </Card>
  )
}
