"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Zap, Download, RotateCcw } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface CompressionPanelProps {
  file: File
}

interface CompressionPreset {
  name: string
  quality: number
  imageCompression: number
  description: string
}

export default function CompressionPanel({ file }: CompressionPanelProps) {
  const [quality, setQuality] = useState(75)
  const [imageCompression, setImageCompression] = useState(80)
  const [compressing, setCompressing] = useState(false)
  const [compressedSize, setCompressedSize] = useState<number | null>(null)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [removeMetadata, setRemoveMetadata] = useState(true)
  const [removeFonts, setRemoveFonts] = useState(false)
  const [showExportOptions, setShowExportOptions] = useState(false)
  const [exportFormat, setExportFormat] = useState<"pdf" | "png" | "jpg">("pdf")

  const presets: CompressionPreset[] = [
    {
      name: "Maximum",
      quality: 50,
      imageCompression: 60,
      description: "Smallest file size",
    },
    {
      name: "High",
      quality: 75,
      imageCompression: 80,
      description: "Balanced quality",
    },
    {
      name: "Medium",
      quality: 90,
      imageCompression: 95,
      description: "High quality",
    },
  ]

  const originalSize = file.size
  const estimatedSize = Math.round(originalSize * (quality / 100) * (imageCompression / 100))

  const handleCompress = async () => {
    setCompressing(true)
    setTimeout(() => {
      setCompressedSize(estimatedSize)
      setCompressing(false)
    }, 2000)
  }

  const handleApplyPreset = (preset: CompressionPreset) => {
    setQuality(preset.quality)
    setImageCompression(preset.imageCompression)
  }

  const handleExport = async () => {
    setCompressing(true)
    // Export logic will be implemented based on selected format
    setTimeout(() => {
      setCompressing(false)
      setShowExportOptions(false)
    }, 2000)
  }

  const handleReset = () => {
    setQuality(75)
    setImageCompression(80)
    setCompressedSize(null)
    setRemoveMetadata(true)
    setRemoveFonts(false)
  }

  const savedSize = originalSize - estimatedSize
  const savedPercent = ((savedSize / originalSize) * 100).toFixed(1)

  return (
    <div className="space-y-4">
      {/* Presets */}
      <Card className="p-4 bg-accent/5 border-accent/20">
        <h3 className="font-semibold text-sm mb-3">Compression Presets</h3>
        <div className="grid grid-cols-3 gap-2">
          {presets.map((preset) => (
            <Button
              key={preset.name}
              onClick={() => handleApplyPreset(preset)}
              variant={
                quality === preset.quality && imageCompression === preset.imageCompression ? "default" : "outline"
              }
              className="h-auto py-2 flex flex-col items-start gap-1"
            >
              <span className="text-sm font-medium">{preset.name}</span>
              <span className="text-xs opacity-70">{preset.description}</span>
            </Button>
          ))}
        </div>
      </Card>

      {/* Manual Settings */}
      <Card className="p-4 bg-primary/5 border-primary/20">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-medium">Quality</label>
            <div className="flex items-center gap-3 mt-2">
              <Slider
                value={[quality]}
                onValueChange={(val) => setQuality(val[0])}
                min={10}
                max={100}
                step={5}
                className="flex-1"
              />
              <span className="text-sm font-semibold w-12 text-right">{quality}%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Higher values preserve more detail</p>
          </div>

          <div>
            <label className="text-sm font-medium">Image Compression</label>
            <div className="flex items-center gap-3 mt-2">
              <Slider
                value={[imageCompression]}
                onValueChange={(val) => setImageCompression(val[0])}
                min={10}
                max={100}
                step={5}
                className="flex-1"
              />
              <span className="text-sm font-semibold w-12 text-right">{imageCompression}%</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Advanced Options */}
      <Dialog open={showAdvanced} onOpenChange={setShowAdvanced}>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full bg-transparent">
            Advanced Options
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Advanced Compression Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="metadata" className="text-base">
                Remove Metadata
              </Label>
              <input
                id="metadata"
                type="checkbox"
                checked={removeMetadata}
                onChange={(e) => setRemoveMetadata(e.target.checked)}
                className="w-4 h-4 cursor-pointer"
              />
            </div>
            <p className="text-xs text-muted-foreground">Removes author, creation date, and other metadata</p>

            <div className="flex items-center justify-between">
              <Label htmlFor="fonts" className="text-base">
                Remove Unused Fonts
              </Label>
              <input
                id="fonts"
                type="checkbox"
                checked={removeFonts}
                onChange={(e) => setRemoveFonts(e.target.checked)}
                className="w-4 h-4 cursor-pointer"
              />
            </div>
            <p className="text-xs text-muted-foreground">Removes fonts not used in the document</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Size Estimates */}
      <Card className="p-4 space-y-3">
        <h3 className="font-semibold text-sm">Size Estimates</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Original</span>
            <span className="font-medium">{(originalSize / 1024 / 1024).toFixed(2)} MB</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Estimated</span>
            <span className="font-medium">{(estimatedSize / 1024 / 1024).toFixed(2)} MB</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-accent transition-all"
              style={{ width: `${(estimatedSize / originalSize) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Saved</span>
            <span className="font-medium text-green-600">
              {(savedSize / 1024 / 1024).toFixed(2)} MB ({savedPercent}%)
            </span>
          </div>
        </div>
      </Card>

      {/* Action Buttons */}
      <div className="space-y-2">
        <Button
          onClick={handleCompress}
          disabled={compressing}
          className="w-full gap-2 bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          {compressing ? (
            <>
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              Compressing...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              Compress PDF
            </>
          )}
        </Button>

        <div className="grid grid-cols-2 gap-2">
          <Dialog open={showExportOptions} onOpenChange={setShowExportOptions}>
            <DialogTrigger asChild>
              <Button className="gap-2 bg-primary hover:bg-primary/90" disabled={!compressedSize}>
                <Download className="w-4 h-4" />
                Export
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Export Options</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="format">Export Format</Label>
                  <select
                    id="format"
                    value={exportFormat}
                    onChange={(e) => setExportFormat(e.target.value as "pdf" | "png" | "jpg")}
                    className="w-full px-3 py-2 border rounded-md bg-background mt-2"
                  >
                    <option value="pdf">PDF - Portable Document</option>
                    <option value="png">PNG - Image (High Quality)</option>
                    <option value="jpg">JPG - Image (Smaller Size)</option>
                  </select>
                </div>
                <Button
                  onClick={handleExport}
                  disabled={compressing}
                  className="w-full gap-2 bg-primary hover:bg-primary/90"
                >
                  {compressing ? "Exporting..." : "Download"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button onClick={handleReset} variant="outline" className="gap-2 bg-transparent">
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
        </div>
      </div>

      {/* Info Box */}
      <Card className="p-3 bg-muted/50 space-y-2">
        <p className="text-xs font-medium">💡 Compression Tips</p>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>• Lower quality = smaller file size</li>
          <li>• Remove metadata for additional savings</li>
          <li>• Export as JPG for maximum compression</li>
        </ul>
      </Card>
    </div>
  )
}
