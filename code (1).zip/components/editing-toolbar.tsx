"use client"

import { useState } from "react"
import {
  Bold,
  Italic,
  Type,
  Highlighter,
  PenTool,
  Plus,
  Trash2,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import AnnotationTools from "./annotation-tools"

interface TextBox {
  id: string
  x: number
  y: number
  text: string
  fontSize: number
  fontFamily: string
  bold: boolean
  italic: boolean
  underline: boolean
  textColor: string
  alignment: "left" | "center" | "right"
}

interface Annotation {
  id: string
  type: "highlight" | "comment" | "draw"
  x: number
  y: number
  text?: string
  color: string
  width?: number
  points?: Array<{ x: number; y: number }>
}

interface EditingToolbarProps {
  onModeChange: (mode: "text" | "annotate" | "draw" | null) => void
  currentMode: string | null
  textBoxes: TextBox[]
  onAddTextBox: (textBox: Omit<TextBox, "id" | "x" | "y">) => void
  onUpdateTextBox: (id: string, updates: Partial<TextBox>) => void
  onDeleteTextBox: (id: string) => void
  selectedTextBoxId: string | null
  onSelectTextBox: (id: string | null) => void
  annotations: Annotation[]
  onAddAnnotation: (annotation: Omit<Annotation, "id">) => void
  onDeleteAnnotation: (id: string) => void
  onClearAnnotations: () => void
}

export default function EditingToolbar({
  onModeChange,
  currentMode,
  textBoxes,
  onAddTextBox,
  onUpdateTextBox,
  onDeleteTextBox,
  selectedTextBoxId,
  onSelectTextBox,
  annotations,
  onAddAnnotation,
  onDeleteAnnotation,
  onClearAnnotations,
}: EditingToolbarProps) {
  const [showAddTextBox, setShowAddTextBox] = useState(false)
  const [newTextContent, setNewTextContent] = useState("")
  const [fontSize, setFontSize] = useState(14)
  const [fontFamily, setFontFamily] = useState("Arial")
  const [textColor, setTextColor] = useState("#000000")
  const [isBold, setIsBold] = useState(false)
  const [isItalic, setIsItalic] = useState(false)
  const [isUnderline, setIsUnderline] = useState(false)
  const [alignment, setAlignment] = useState<"left" | "center" | "right">("left")

  const handleAddTextBox = () => {
    if (!newTextContent.trim()) return

    onAddTextBox({
      text: newTextContent,
      fontSize,
      fontFamily,
      bold: isBold,
      italic: isItalic,
      underline: isUnderline,
      textColor,
      alignment,
    })

    setNewTextContent("")
    setShowAddTextBox(false)
    resetFormatting()
  }

  const resetFormatting = () => {
    setFontSize(14)
    setFontFamily("Arial")
    setTextColor("#000000")
    setIsBold(false)
    setIsItalic(false)
    setIsUnderline(false)
    setAlignment("left")
  }

  const handleSelectTextBox = (box: TextBox) => {
    onSelectTextBox(box.id)
    setFontSize(box.fontSize)
    setFontFamily(box.fontFamily)
    setTextColor(box.textColor)
    setIsBold(box.bold)
    setIsItalic(box.italic)
    setIsUnderline(box.underline)
    setAlignment(box.alignment)
  }

  const handleUpdateFormatting = () => {
    if (!selectedTextBoxId) return

    onUpdateTextBox(selectedTextBoxId, {
      fontSize,
      fontFamily,
      bold: isBold,
      italic: isItalic,
      underline: isUnderline,
      textColor,
      alignment,
    })
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-2">
        <Button
          onClick={() => onModeChange(currentMode === "text" ? null : "text")}
          variant={currentMode === "text" ? "default" : "outline"}
          className="justify-start h-auto py-3"
        >
          <Type className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Edit Text</div>
            <div className="text-xs opacity-70">Add or modify text content</div>
          </div>
        </Button>
        <Button
          onClick={() => onModeChange(currentMode === "annotate" ? null : "annotate")}
          variant={currentMode === "annotate" ? "default" : "outline"}
          className="justify-start h-auto py-3"
        >
          <Highlighter className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Annotate</div>
            <div className="text-xs opacity-70">Highlight and comment</div>
          </div>
        </Button>
        <Button
          onClick={() => onModeChange(currentMode === "draw" ? null : "draw")}
          variant={currentMode === "draw" ? "default" : "outline"}
          className="justify-start h-auto py-3"
        >
          <PenTool className="w-4 h-4 mr-3" />
          <div className="text-left">
            <div className="font-medium text-sm">Draw</div>
            <div className="text-xs opacity-70">Draw freehand marks</div>
          </div>
        </Button>
      </div>

      {currentMode === "annotate" && (
        <AnnotationTools
          annotations={annotations}
          onAddAnnotation={onAddAnnotation}
          onDeleteAnnotation={onDeleteAnnotation}
          onClearAnnotations={onClearAnnotations}
        />
      )}

      {currentMode === "text" && (
        <>
          <Dialog open={showAddTextBox} onOpenChange={setShowAddTextBox}>
            <DialogTrigger asChild>
              <Button className="w-full gap-2 bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4" />
                Add Text Box
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Text Box</DialogTitle>
                <DialogDescription>Add new text to your PDF</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="text-content">Text Content</Label>
                  <textarea
                    id="text-content"
                    value={newTextContent}
                    onChange={(e) => setNewTextContent(e.target.value)}
                    placeholder="Enter your text here..."
                    className="w-full px-3 py-2 border rounded-md bg-background min-h-24"
                  />
                </div>
                <Button onClick={handleAddTextBox} className="w-full bg-primary hover:bg-primary/90">
                  Add Text Box
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {textBoxes.length > 0 && (
            <Card className="p-4 space-y-3">
              <h3 className="font-semibold text-sm">Text Boxes ({textBoxes.length})</h3>
              <div className="space-y-2 max-h-48 overflow-auto">
                {textBoxes.map((box) => (
                  <div
                    key={box.id}
                    onClick={() => handleSelectTextBox(box)}
                    className={`p-2 rounded border cursor-pointer transition-all ${
                      selectedTextBoxId === box.id
                        ? "border-primary bg-primary/10"
                        : "border-input hover:border-primary/50"
                    }`}
                  >
                    <div className="text-sm font-medium truncate">{box.text}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {box.fontSize}px • {box.fontFamily}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {selectedTextBoxId && (
            <Card className="p-4 space-y-4">
              <h3 className="font-semibold text-sm">Text Formatting</h3>
              <div className="grid grid-cols-4 gap-2">
                <Button
                  variant={isBold ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setIsBold(!isBold)
                    handleUpdateFormatting()
                  }}
                >
                  <Bold className="w-4 h-4" />
                </Button>
                <Button
                  variant={isItalic ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setIsItalic(!isItalic)
                    handleUpdateFormatting()
                  }}
                >
                  <Italic className="w-4 h-4" />
                </Button>
                <Button
                  variant={isUnderline ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setIsUnderline(!isUnderline)
                    handleUpdateFormatting()
                  }}
                >
                  <Underline className="w-4 h-4" />
                </Button>
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => {
                    setTextColor(e.target.value)
                    handleUpdateFormatting()
                  }}
                  className="w-full h-9 rounded border border-input cursor-pointer"
                />
              </div>

              <div>
                <Label htmlFor="font-family">Font Family</Label>
                <select
                  id="font-family"
                  value={fontFamily}
                  onChange={(e) => {
                    setFontFamily(e.target.value)
                    handleUpdateFormatting()
                  }}
                  className="w-full px-3 py-2 border rounded-md bg-background text-sm mt-1"
                >
                  <option>Arial</option>
                  <option>Times New Roman</option>
                  <option>Courier</option>
                  <option>Helvetica</option>
                  <option>Georgia</option>
                </select>
              </div>

              <div>
                <Label htmlFor="font-size">Font Size: {fontSize}px</Label>
                <input
                  id="font-size"
                  type="range"
                  min="8"
                  max="48"
                  value={fontSize}
                  onChange={(e) => {
                    setFontSize(Number(e.target.value))
                    handleUpdateFormatting()
                  }}
                  className="w-full mt-1"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant={alignment === "left" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setAlignment("left")
                    handleUpdateFormatting()
                  }}
                >
                  <AlignLeft className="w-4 h-4" />
                </Button>
                <Button
                  variant={alignment === "center" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setAlignment("center")
                    handleUpdateFormatting()
                  }}
                >
                  <AlignCenter className="w-4 h-4" />
                </Button>
                <Button
                  variant={alignment === "right" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setAlignment("right")
                    handleUpdateFormatting()
                  }}
                >
                  <AlignRight className="w-4 h-4" />
                </Button>
              </div>

              <Button
                variant="destructive"
                className="w-full gap-2"
                onClick={() => {
                  onDeleteTextBox(selectedTextBoxId)
                  onSelectTextBox(null)
                }}
              >
                <Trash2 className="w-4 h-4" />
                Delete Text Box
              </Button>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
