"use client"

import { useState } from "react"
import { ChevronLeft, Download, Zap, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PDFPreview from "./pdf-preview"
import EditingToolbar from "./editing-toolbar"
import AIAssistant from "./ai-assistant"
import CompressionPanel from "./compression-panel"
import PageManagement from "./page-management"

interface TextBox {
  id: string
  x: number
  y: number
  text: string
  fontSize: number
  fontFamily: string
  bold: boolean
  italic: boolean
  underline: boolean
  textColor: string
  alignment: "left" | "center" | "right"
}

interface Annotation {
  id: string
  type: "highlight" | "comment" | "draw"
  x: number
  y: number
  text?: string
  color: string
  width?: number
  points?: Array<{ x: number; y: number }>
}

interface PDFEditorProps {
  file: File
  onBack: () => void
}

export default function PDFEditor({ file, onBack }: PDFEditorProps) {
  const [editMode, setEditMode] = useState<"text" | "annotate" | "draw" | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [showAI, setShowAI] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [textBoxes, setTextBoxes] = useState<TextBox[]>([])
  const [annotations, setAnnotations] = useState<Annotation[]>([])
  const [selectedTextBoxId, setSelectedTextBoxId] = useState<string | null>(null)

  const handleAddTextBox = (textBox: Omit<TextBox, "id" | "x" | "y">) => {
    const newBox: TextBox = {
      ...textBox,
      id: Date.now().toString(),
      x: 20,
      y: 50,
    }
    setTextBoxes([...textBoxes, newBox])
  }

  const handleUpdateTextBox = (id: string, updates: Partial<TextBox>) => {
    setTextBoxes(textBoxes.map((box) => (box.id === id ? { ...box, ...updates } : box)))
  }

  const handleDeleteTextBox = (id: string) => {
    setTextBoxes(textBoxes.filter((box) => box.id !== id))
    if (selectedTextBoxId === id) setSelectedTextBoxId(null)
  }

  const handleAddAnnotation = (annotation: Omit<Annotation, "id">) => {
    const newAnnotation: Annotation = {
      ...annotation,
      id: Date.now().toString(),
    }
    setAnnotations([...annotations, newAnnotation])
  }

  const handleDeleteAnnotation = (id: string) => {
    setAnnotations(annotations.filter((ann) => ann.id !== id))
  }

  const handleClearAnnotations = () => {
    setAnnotations([])
  }

  const handleExport = async () => {
    setIsExporting(true)
    setTimeout(() => setIsExporting(false), 2000)
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="min-w-0">
              <h1 className="font-semibold truncate text-sm sm:text-base">{file.name}</h1>
              <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            <Button variant="outline" size="sm" onClick={() => setShowAI(!showAI)} className="gap-2">
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">AI</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Zap className="w-4 h-4" />
              <span className="hidden sm:inline">Compress</span>
            </Button>
            <Button
              size="sm"
              onClick={handleExport}
              disabled={isExporting}
              className="gap-2 bg-primary hover:bg-primary/90"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">{isExporting ? "Exporting..." : "Export"}</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex flex-col md:flex-row gap-4 p-4 sm:p-6">
        {/* Left Panel - PDF Preview */}
        <div className="flex-1 min-w-0 flex flex-col">
          <PDFPreview
            file={file}
            currentPage={currentPage}
            onPageChange={setCurrentPage}
            onTotalPagesChange={setTotalPages}
            editMode={editMode}
            textBoxes={textBoxes}
            annotations={annotations}
          />
        </div>

        {/* Right Sidebar - Tools */}
        <div className="w-full md:w-80 flex flex-col gap-4">
          {/* AI Assistant */}
          {showAI && <AIAssistant fileName={file.name} />}

          {/* Tools Tabs */}
          <Tabs defaultValue="edit" className="flex-1 flex flex-col min-h-0">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="edit">Tools</TabsTrigger>
              <TabsTrigger value="compress">Compress</TabsTrigger>
              <TabsTrigger value="pages">Pages</TabsTrigger>
            </TabsList>

            <TabsContent value="edit" className="flex-1 overflow-auto">
              <EditingToolbar
                onModeChange={setEditMode}
                currentMode={editMode}
                textBoxes={textBoxes}
                onAddTextBox={handleAddTextBox}
                onUpdateTextBox={handleUpdateTextBox}
                onDeleteTextBox={handleDeleteTextBox}
                selectedTextBoxId={selectedTextBoxId}
                onSelectTextBox={setSelectedTextBoxId}
                annotations={annotations}
                onAddAnnotation={handleAddAnnotation}
                onDeleteAnnotation={handleDeleteAnnotation}
                onClearAnnotations={handleClearAnnotations}
              />
            </TabsContent>

            <TabsContent value="compress" className="flex-1 overflow-auto">
              <CompressionPanel file={file} />
            </TabsContent>

            <TabsContent value="pages" className="flex-1 overflow-auto">
              <PageManagement totalPages={totalPages} currentPage={currentPage} onPageChange={setCurrentPage} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Footer - Page Navigation */}
      <footer className="border-t bg-card/50 backdrop-blur-sm px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="text-sm text-muted-foreground">
            Page <span className="font-semibold">{currentPage}</span> of{" "}
            <span className="font-semibold">{totalPages}</span>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      </footer>
    </div>
  )
}
